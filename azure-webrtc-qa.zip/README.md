This browser harness compares ordinary Azure WebRTC usage with LiteLLM accounting.

Use a provisioned LiteLLM checkout with its Python environment in `.venv`. Set `AZURE_API_BASE` to your Azure resource endpoint and `AZURE_API_KEY` to its API key. The resource needs `gpt-realtime-2.1` and `gpt-live-transcribe` deployments. Credentials are supplied through environment variables and never shown by the page.

Run from this extracted directory, replacing the checkout path with your LiteLLM checkout.

```bash
/path/to/litellm/.venv/bin/python run.py /path/to/litellm
```

Wait for `LiteLLM is ready`. Open http://127.0.0.1:8765/ in Chrome and click **Run WebRTC audio test**. The page sends the included synthetic speech and reports the provider usage and the current session's proxy records. Results are saved to `webrtc-result.json`. `usage.jsonl` contains sanitized callback records. Stop the launcher with Ctrl-C before switching checkout revisions.

Run at upstream main for Before, then at the PR head for After. Compare observed usage rather than assuming equal token counts across separate model responses. Parent response usage and nested transcription usage should each have one accounting record after the change. Provider costs are estimates from LiteLLM's model pricing, without invoice reconciliation.

The launcher binds ports 4000 and 8765 to localhost. This harness is for local verification and does not add database persistence, active-call termination, or production authentication to the demo server.
