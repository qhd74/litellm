import json
import os
import re
from pathlib import Path

from litellm.integrations.custom_logger import CustomLogger
from litellm.constants import LITELLM_PROXY_MASTER_KEY_ALIAS


class UsageRecorder(CustomLogger):
    def record(self, kind, kwargs, response_obj=None):
        standard = kwargs.get("standard_logging_object") or {}
        usage = standard.get("usage") or kwargs.get("combined_usage_object") or getattr(response_obj, "usage", None)
        if not usage and standard.get("total_tokens"):
            usage = {field: standard.get(field) for field in ("prompt_tokens", "completion_tokens", "total_tokens")}
        if hasattr(usage, "model_dump"):
            usage = usage.model_dump()
        metadata = (kwargs.get("litellm_params") or {}).get("metadata") or {}
        results = getattr(response_obj, "results", None) or (response_obj if isinstance(response_obj, list) else [])
        transcription_usage = [event.get("usage") for event in results if hasattr(event, "get") and event.get("type") == "conversation.item.input_audio_transcription.completed"]
        owner = metadata.get("user_api_key")
        if not isinstance(owner, str) or not (owner == LITELLM_PROXY_MASTER_KEY_ALIAS or re.fullmatch(r"[a-f0-9]{64}", owner)):
            owner = None
        provider_response_id = next((event.get("response", {}).get("id") for event in results if hasattr(event, "get") and event.get("type") == "response.done"), None)
        provider_session_id = next((event.get("session", {}).get("id") for event in results if hasattr(event, "get") and event.get("type") == "session.updated"), None)
        entry = {
            "kind": kind,
            "model": kwargs.get("model"),
            "call_type": kwargs.get("call_type"),
            "usage": usage,
            "transcription_usage": transcription_usage,
            "call_id": metadata.get("webrtc_call_id"),
            "usage_model": metadata.get("webrtc_usage_model"),
            "accounting_status": metadata.get("webrtc_accounting_status"),
            "owner": owner,
            "provider_response_id": provider_response_id,
            "provider_session_id": provider_session_id,
            "response_cost": standard.get("response_cost", kwargs.get("response_cost")),
        }
        with Path(os.environ["LAB_USAGE_FILE"]).open("a") as output:
            output.write(json.dumps(entry, default=str) + "\n")

    async def async_pre_call_hook(self, user_api_key_dict, cache, data, call_type):
        self.record("admission", {"model": data.get("model"), "call_type": call_type})
        return data

    async def async_log_success_event(self, kwargs, response_obj, start_time, end_time):
        self.record("success", kwargs, response_obj)

    async def async_log_failure_event(self, kwargs, response_obj, start_time, end_time):
        self.record("failure", kwargs)


recorder = UsageRecorder()

