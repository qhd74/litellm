import asyncio
import base64
import json
import os
import wave
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from websockets.asyncio.client import connect
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, Response

ROOT = Path(__file__).resolve().parent
app = FastAPI()
sideband_report = {}
sideband_socket = None
sideband_task = None


def headers():
    return {"Authorization": "Bearer " + os.environ["LITELLM_MASTER_KEY"]}


@app.get("/")
async def page():
    return FileResponse(ROOT / "index.html")


@app.get("/input.wav")
async def audio():
    return FileResponse(ROOT / "input.wav", media_type="audio/wav")


@app.get("/proxy-observations")
async def observations():
    path = Path(os.environ["LAB_USAGE_FILE"])
    records = [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []
    return {"records": records, "usage_records": sum(bool(item.get("usage")) for item in records)}


@app.post("/negotiate")
async def negotiate(request: Request):
    body = await request.json()
    async with httpx.AsyncClient(timeout=35, trust_env=False) as client:
        token_response = await client.post(
            "http://127.0.0.1:4000/v1/realtime/client_secrets",
            headers=headers(),
            json={"model": "azure-realtime", "session": {"type": "realtime", "model": "azure-realtime"}},
        )
        if not token_response.is_success:
            return JSONResponse({"step": "client_secrets", "status": token_response.status_code, "error": token_response.json()}, status_code=502)
        token = token_response.json()["value"]
        answer = await client.post(
            "http://127.0.0.1:4000/v1/realtime/calls",
            headers={"Authorization": "Bearer " + token, "Content-Type": "application/sdp"},
            content=body["sdp"],
        )
        if not answer.is_success:
            return JSONResponse({"step": "calls", "status": answer.status_code, "error": answer.text}, status_code=502)
        return Response(answer.content, media_type="application/sdp")


@app.post("/client-result")
async def result(request: Request):
    body = await request.json()
    (ROOT / "webrtc-result.json").write_text(json.dumps(body, indent=2))
    return {"saved": True}


