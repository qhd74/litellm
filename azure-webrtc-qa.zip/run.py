import os
import secrets
import signal
import sys
import subprocess
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent
CLONE = Path(sys.argv[1]).resolve()


def environment():
    if not os.environ.get("AZURE_API_KEY") or not os.environ.get("AZURE_API_BASE"):
        raise SystemExit("Set AZURE_API_KEY and AZURE_API_BASE before running the test")
    return {
        **os.environ,
        "LITELLM_MASTER_KEY": os.environ.get("LITELLM_MASTER_KEY") or "sk-local-" + secrets.token_urlsafe(24),
        "PYTHONPATH": str(ROOT) + os.pathsep + str(CLONE),
        "LAB_USAGE_FILE": str(ROOT / "usage.jsonl"),
        "LITELLM_RUST": "false",
    }


def wait_for_proxy(process):
    print("Waiting for LiteLLM readiness...", flush=True)
    deadline = time.monotonic() + 90
    with httpx.Client(trust_env=False, timeout=1) as client:
        while process.poll() is None:
            try:
                if client.get("http://127.0.0.1:4000/health/liveliness").status_code == 200:
                    print("LiteLLM is ready", flush=True)
                    return
            except httpx.TransportError:
                pass
            if time.monotonic() >= deadline:
                raise SystemExit("LiteLLM did not become ready. Check the private proxy.log.")
            time.sleep(0.25)
    raise SystemExit("LiteLLM exited before it became ready. Check the private proxy.log.")


def main():
    env = environment()
    processes = []
    logs = []
    try:
        for name, command, working in (
            (
                "proxy",
                [str(CLONE / ".venv/bin/python"), "-m", "litellm.proxy.proxy_cli", "--config", str(ROOT / "config.yaml"), "--host", "127.0.0.1", "--port", "4000"],
                CLONE,
            ),
            (
                "harness",
                [str(CLONE / ".venv/bin/python"), "-m", "uvicorn", "harness:app", "--host", "127.0.0.1", "--port", "8765"],
                ROOT,
            ),
        ):
            log_path = ROOT / (name + ".log")
            log = log_path.open("w")
            os.chmod(log_path, 0o600)
            logs.append(log)
            process = subprocess.Popen(command, cwd=working, env=env, stdout=log, stderr=subprocess.STDOUT)
            processes.append(process)
            print(name + " PID " + str(process.pid), flush=True)
            if name == "proxy":
                wait_for_proxy(process)
        print("Open http://127.0.0.1:8765/ and run the WebRTC audio test", flush=True)
        while all(process.poll() is None for process in processes):
            time.sleep(1)
        print("A local service exited. Inspect its sanitized log.", flush=True)
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
        for process in processes:
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        for log in logs:
            log.close()


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    try:
        main()
    except KeyboardInterrupt:
        pass

